import { Component } from '@angular/core';

@Component({
  selector: 'about-page',
  template: `
    i am the about page
  `
})
export class AboutComponent {}