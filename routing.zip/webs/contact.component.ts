import { Component } from '@angular/core';

@Component({
  selector: 'contact-page',
  template: `
    i am the contact page
  `
})
export class ContactComponent {}