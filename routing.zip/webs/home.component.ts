import { Component } from '@angular/core';

@Component({
  selector: 'home-page',
  template: `
    i am the home page
  `
})
export class HomeComponent {}